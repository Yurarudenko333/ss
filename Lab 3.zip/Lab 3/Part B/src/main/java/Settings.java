public class Settings {
    public static final int CUSTOMER_COUNT = 32;
    public static final int SLEEP_TIME = 100;
}
