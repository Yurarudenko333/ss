public class Settings {
    public static final int JAR_VOLUME = 16;
    public static final int BEES_COUNT = 4;
    public static final int SLEEP_INTERVAL = 50;
}
