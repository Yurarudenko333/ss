public class Settings {
    public static final int RECRUIT_COUNT = 20;

    public static final int BLOCK_SIZE = 5;

    public static final int SLEEP_TIME = 100;

}
