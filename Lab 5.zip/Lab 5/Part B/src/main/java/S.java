public class S {
    public static final int SLEEP_TIME = 100;

    public static final int THREAD_COUNT = 4;
    public static final int STRING_LEN = 2;
}
