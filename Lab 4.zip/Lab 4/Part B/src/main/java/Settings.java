public class Settings {
    public static final int ROWS = 5;
    public static final int COLUMNS = 5;

    public static final int SLEEP_TIME = 1000;

    public static final int DRIED = 3;

    public static final String FILE = "garden.maf";
}
